document.addEventListener("deviceready",onDeviceReady,false);
function onDeviceReady(){
    console.log("ready...");
    creatTrun();//加载轮播图
    getJsonArray();//获取新闻列表
    handSearch();//处理搜索数据，并从服务端得到搜索结果数据

    $("#home").click(function(){
        creatTrun();//加载轮播图
    });   
}
var URL="http://192.168.43.12:9090";//URL是服务器的地址
var newsData;//newsdata是存储全部新闻的全局变量
var lastid;//lastid是当前列表最后的文章id

// 从服务器获取新闻列表
function getJsonArray(){
    $.ajax({
        url : URL+"/myNews/GetJson?callback=?",
        type : "get",
        dataType : "jsonp",
        jsonp:"callback",
        success : function(data) {	
            newsData=data;//将从服务器获得的内容赋给newsData
            console.log(newsData);//测试输出newsData
            createList();//将新闻绑定到id为#newsList的列表
            
        },
        error : function() {
            alert("error...");
        }
    }); 
}

//动态创建新闻列表项
function createList(){
     var mb = document.createElement("li");
    //列表替换模板
     mb = '<li id="@liid" value="@idvalue" data-icon="false" ><a href="#contentPage"><h1>@title</h1><p>@author&nbsp&nbsp@pudate</p></a></li>';

    //首次加载，动态读取前10条新闻
   for(var i=0;i<10;i++)
    {
        var tmp=mb;
        tmp=tmp.replace("@liid","li"+i);
        tmp=tmp.replace("@idvalue",newsData[i].id);//替换新标题
        tmp=tmp.replace("@title",newsData[i].title);//替换新闻标题
        tmp=tmp.replace("@author",newsData[i].author);//替换作者
        tmp=tmp.replace("@pudate",newsData[i].pudate);//替换发布日期

        $("#newsList").prepend(tmp);//添加列表项
    }
    $("#newsList").listview("refresh");//刷新列表样式
    lastid=$("#newsList li").attr("value");//取出首次加载完成后当前列表的文章id
    createContent();//创建新闻详情页面 
    clickRefresh();//点击“首页”按钮，实现每次刷新5条新闻 
}

//动态创建新闻详情页面
function createContent(){
    $("#newsList li").click(function(){//获得点击事件
        var id=$(this).attr("value");//取当前选中 li 的value值
        //将id值通过ajax发送servlet,进行查询，并返回查询内容
         $.ajax({
            url : URL+"/myNews/SearchJson?callback=?",
                    type : "get",
                    dataType : "jsonp",
                    jsonp:"callback",
                    data:{"id":id},
            success : function(data) {	
                newsData=data;//将从服务器获得的内容赋给newsData
                addContent();//添加新闻详情内容
            },
            error : function() {
                alert("error...");
            }
         });   
    });
}

//添加新闻详情
function addContent(){
    //先清空上次添加内容(文字+图片)
    $("#newsContent").html("");
    $("#newsImg img").prop("src", "");

    var mb = document.createElement("div");//mb是div元素变量
    //替代模板
    mb = '<div id="contentId"><h3>@title</h3><p>@author&nbsp&nbsp@pudate</p><p>@content</p></div>';
	//添加新闻详情
	var tmp=mb;//temp是临时交换变量
	tmp=tmp.replace("@title",newsData[0].title);//替换新闻标题
	tmp=tmp.replace("@author",newsData[0].author);//替换作者
	tmp=tmp.replace("@pudate",newsData[0].pudate);//替换发布日期
	tmp=tmp.replace("@content",newsData[0].content);//替换发布日期
    $("#newsContent").append(tmp);//添加到页面上
    //添加新闻图片
    addPic(newsData[0].img);
}

//添加新闻图片的方法
function addPic(Data)
{
    var address=URL+Data;//对应图片的地址    
    $("#newsImg img").prop("src", address);//替换选择器#newsImg Img的src的属性    
}

//点击“首页”按钮，实现每次刷新加载5条新闻
function clickRefresh(){
    $("#refresh").click(function(){//获得点击事件
        //将lastid值通过ajax发送servlet,进行查询，并返回查询内容
        $.ajax({
            url : URL+"/myNews/AddRefresh?callback=?",
                    type : "get",
                    dataType : "jsonp",
                    jsonp:"callback",
                    data:{"lastid":lastid},
            success : function(data) {	
                newsData=data;//将从服务器获得的内容赋给newsData
                addNew();//增加5条新的新闻
                createContent();//创建新闻详情页面 
            },
            error : function() {
                alert("error...");
            }
        }); 

    });    
}

//刷新增加5条新的新闻
function addNew(){
    var mb = document.createElement("li");
    //列表替换模板
     mb = '<li id="@liid" value="@idvalue" data-icon="false" ><a href="#contentPage"><h1>@title</h1><p>@author&nbsp&nbsp@pudate</p></a></li>';
	for(var i=0;i<5;i++)
    {
        var tmp=mb;
        tmp=tmp.replace("@liid","li"+i);
        tmp=tmp.replace("@idvalue",newsData[i].id);//替换新标题
        tmp=tmp.replace("@title",newsData[i].title);//替换新闻标题
        tmp=tmp.replace("@author",newsData[i].author);//替换作者
        tmp=tmp.replace("@pudate",newsData[i].pudate);//替换发布日期
        $("#newsList").prepend(tmp);//添加列表项
    }
    $("#newsList").listview("refresh");//刷新列表样式
    lastid=$("#newsList li").attr("value");//取出上次刷新完成后当前列表的文章id
}


//处理搜索数据，并从服务端得到搜索结果数据
function handSearch(){
    
    //页面切换时，清空搜索页面列表内容
    $("#clearSearch").click(function(){
        $("#searchReturn").html("");
    });

    //重置表单
    $("#reset").click(function(){//获得点击事件
        $("#myForm").reset;
    });

    //获得"点击搜索"事件
    $("#search").click(function(){
        
       //将input值通过ajax发送servlet,进行查询，并返回查询内容
        $.ajax({
            url : URL+"/myNews/ReturnSearch?callback=?",
                    type : "get",
                    dataType : "jsonp",
                    jsonp:"callback",
                    data:{"input":$('form input[name=inputSearch]').val()},
            success : function(data) {
                newsData=data;//将从服务器获得的内容赋给newsData
                addReturnList();//增加与搜索相关的新闻列表
                addReturnContent();//增加与搜索相关的新闻详情页面
            },
            error : function() {
                alert("error...");
            }
        }); 
    });
    
}
//创建与搜索相关的新闻列表页面
function addReturnList(){
    var mb = document.createElement("li");
    //列表替换模
     mb = '<li id="@liid" value="@idvalue" data-icon="false" ><a href="#contentPage"><h1>@title</h1><p>@author&nbsp&nbsp@pudate</p></a></li>';

     $("#searchReturn").html("");

        for(var i=0;i<newsData.length;i++)
        {
            var tmp=mb;
            tmp=tmp.replace("@liid",i);
            tmp=tmp.replace("@idvalue",newsData[i].id);//替换新标题
            tmp=tmp.replace("@title",newsData[i].title);//替换新闻标题
            tmp=tmp.replace("@author",newsData[i].author);//替换作者
            tmp=tmp.replace("@pudate",newsData[i].pudate);//替换发布日期
            $("#searchReturn").prepend(tmp);//添加列表项
        }
        $("#searchReturn").listview("refresh");//刷新列表样式

}
//增加与搜索相关的新闻详情页面
function addReturnContent(){
     
    $("#searchReturn li").click(function(){
        //先清空上次添加内容(文字+图片)
        $("#newsContent").html("");
        $("#newsImg img").prop("src", "");
        var id=$(this).attr("id");//取当前选中 li 的value值
        var mb = document.createElement("div");//mb是div元素变量
        //替代模板
        mb = '<div id="contentId"><h3>@title</h3><p>@author&nbsp&nbsp@pudate</p><p>@content</p></div>';
        //添加新闻详情
        var tmp=mb;//temp是临时交换变量
        tmp=tmp.replace("@title",newsData[id].title);//替换新闻标题
        tmp=tmp.replace("@author",newsData[id].author);//替换作者
        tmp=tmp.replace("@pudate",newsData[id].pudate);//替换发布日期
        tmp=tmp.replace("@content",newsData[id].content);//替换发布日期
        $("#newsContent").append(tmp);//添加到页面上
        //添加新闻图片
        addPic(newsData[id].img);
    }); 
}

//添加轮播图
function creatTrun(){
	imgReload();
    var unslider = $('#turnImg').unslider({
		dots: true,
		fluid: true
	}),
	data = unslider.data('unslider');
	
	$('.unslider-arrow').click(function() {
        var fn = this.className.split(' ')[1];
        data[fn]();
    });

    $(window).resize(function(){imgReload();});

}
//轮播图重新加载
function imgReload()
{
	var imgHeight = 0;
	var wtmp = $("body").width();
	$("#turnImg ul li").each(function(){
        $(this).css({width:wtmp + "px"});
    });
	$(".sliderimg").each(function(){
		$(this).css({width:wtmp + "px"});
		imgHeight = $(this).height();
	});
}


//app退出方法
function back() {  
    if (confirm('是否关闭?')) {  
        window.close();
        return;  
    }  
} 