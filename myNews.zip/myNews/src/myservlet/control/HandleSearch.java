package myservlet.control;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mybean.data.ShowSearch;

public class HandleSearch extends HttpServlet{
	public void init(ServletConfig config) throws ServletException{
	      super.init(config);
	   }
	   public void doPost(HttpServletRequest request,HttpServletResponse response)
	               throws ServletException,IOException{
	      ShowSearch resultBean=null;
	      try{  resultBean=(ShowSearch)request.getAttribute("resultBean");
	            if(resultBean==null){
	                resultBean=new ShowSearch(); //����Javabean����
	                request.setAttribute("resultBean",resultBean);
	            }
	      }
	      catch(Exception exp){
	            resultBean=new ShowSearch();  //����Javabean����
	            request.setAttribute("resultBean",resultBean);
	      } 
	     try{  Class.forName("com.mysql.jdbc.Driver");
	     }
	     catch(Exception e){} 
	     String searchMess = request.getParameter("searchNews");
	     String radioMess = request.getParameter("radio");
	    
	     Connection con;
	     Statement sql; 
	     ResultSet rs;
	     try{ 
	    	 //�������ݿ�
	    	 String uri="jdbc:mysql://127.0.0.1/mynews?"+
                     "user=root&password=123456&characterEncoding=utf-8&useSSL=false";
	    	 con=DriverManager.getConnection(uri);
	    	 sql=con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
                                ResultSet.CONCUR_READ_ONLY);
	    	 //����������ѯ
	    	 String condition="";
	    	 if(searchMess==null||searchMess.length()==0) {
	             fail(request,response,"û�в�ѯ��Ϣ���޷���ѯ");
	             return;
	          }
	         if(radioMess.equals("searchId")) {
	             condition = 
	            "SELECT * FROM tb_news where id ='"+searchMess+"'";
	         }
	         if(radioMess.equals("searchTitle")) {
	             condition = 
	            "SELECT * FROM tb_news where title LIKE '%"+searchMess+"%'"; 
	         }
	         if(radioMess.equals("searchAuthor")) {
	             condition = 
	            "SELECT * FROM tb_news where author LIKE '%"+searchMess+"%'"; 
	         }
	         if(radioMess.equals("searchPudate")) {
	             condition = 
	            "SELECT * FROM tb_news where pudate LIKE '%"+searchMess+"%'"; 
	         }         
//	       ִ�в�ѯ���
	          rs=sql.executeQuery(condition);
	          ResultSetMetaData metaData = rs.getMetaData();
	          int columnCount = metaData.getColumnCount(); //�õ������������
	          String []columnName = new String[columnCount];
	          for(int i=0;i<columnName.length;i++) {
	             columnName[i] = metaData.getColumnName(i+1); //�õ�����
	          }
	          resultBean.setColumnName(columnName);   //����Javabean����ģ��
	          rs.last();
	          int rowNumber=rs.getRow();  //�õ���¼��
	          String [][] tableRecord=resultBean.getTableRecord();
	          tableRecord = new String[rowNumber][columnCount];
	          rs.beforeFirst();
	          int i=0;
	          while(rs.next()){
	            for(int k=0;k<columnCount;k++) 
	              tableRecord[i][k] = rs.getString(k+1);
	            i++; 
	          }
	          resultBean.setTableRecord(tableRecord); //����Javabean����ģ��
	          con.close();
	          RequestDispatcher dispatcher=
	          request.getRequestDispatcher("showRecord.jsp");
	          dispatcher.forward(request,response);
	     }
	     catch(SQLException e){
	          System.out.println(e);
	     }  
	   }
	   public  void  doGet(HttpServletRequest request,HttpServletResponse response)
	           throws ServletException,IOException{
	       doPost(request,response);
	   }
	   public void fail(HttpServletRequest request,HttpServletResponse response,
               String backNews) {
		 response.setContentType("text/html;charset=utf-8");
		 try {
			  PrintWriter out=response.getWriter();
			  out.println("<html><body>");
			  out.println("<h2>"+backNews+"</h2>") ;
			  out.println("���أ�");
			  out.println("<a href =queryNews.jsp>��ѯ����</a>");
			  out.println("</body></html>");
		 }
		 catch(IOException exp){}
		}
}
