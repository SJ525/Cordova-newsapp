package myservlet.control;
import mybean.data.News;
import java.sql.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class HandleInput extends HttpServlet{
	public void init(ServletConfig config) throws ServletException{
	      super.init(config);
	   }
	   public void doPost(HttpServletRequest request,HttpServletResponse response)
	               throws ServletException,IOException{
		  
	      News resultBean=null;
	      try{  resultBean=(News)request.getAttribute("resultBean");
	            if(resultBean==null){
	                resultBean=new News(); //����Javabean����
	                request.setAttribute("resultBean",resultBean);
	            }
	      }
	      catch(Exception exp){
	            resultBean=new News();  //����Javabean����
	            request.setAttribute("resultBean",resultBean);
	      } 
	     try{  Class.forName("com.mysql.jdbc.Driver");
	     }
	     catch(Exception e){} 
	     request.setCharacterEncoding("utf-8");
	     String id=request.getParameter("id");//���
	     String tit=request.getParameter("title");//����
	     String aut=request.getParameter("author");//����
	     String pud=request.getParameter("pudate");//����ʱ��
	     String cont=request.getParameter("content");//����
	     if(id==null||id.length()==0) {
	        fail(request,response,"���Ӽ�¼ʧ��,���������¼");
	        return;
	     }
	     int id1=Integer.parseInt(id);
	     
	     String condition = "INSERT into tb_news(id, title, author,pudate,content) VALUES"+
	     "("+id1+",'"+tit+"','"+aut+"','"+pud+"','"+cont+"')";
	     
	     Connection con;
	     Statement sql; 
	     try{ 
	          String uri="jdbc:mysql://127.0.0.1/mynews?"+
	                      "user=root&password=123456&characterEncoding=utf-8&useSSL=false";
	          con=DriverManager.getConnection(uri);
	          sql=con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
	                                 ResultSet.CONCUR_UPDATABLE);
	          sql.executeUpdate(condition);
	          try {
	        	  response.setContentType("text/html;charset=utf-8");
				  PrintWriter out=response.getWriter();
				  out.println("<html><body>");
				  out.println("<h2>"+"�������ųɹ�"+"</h2>");
				  out.println("<a href =inputNews.jsp>��������ҳ��</a>");
				  out.println("</body></html>");
			} catch (Exception e) {
				e.printStackTrace();
			}
	          con.close();
	     }
	     catch(SQLException e){
	          System.out.println(e);
	          fail(request,response,"��������ʧ��:"+e.toString());
	     }  
	   }
	   public  void  doGet(HttpServletRequest request,HttpServletResponse response)
	           throws ServletException,IOException{
	       doPost(request,response);
	   }
	   public void fail(HttpServletRequest request,HttpServletResponse response,
	                      String backNews) {
	        response.setContentType("text/html;charset=utf-8");
	        try {
	         PrintWriter out=response.getWriter();
	         out.println("<html><body>");
	         out.println("<h2>"+"��������ʧ��"+"</h2>") ;
	         out.println("<a href =inputNews.jsp>��������</a>");
	         out.println("</body></html>");
	        }
	        catch(IOException exp){} 
	    }
}
