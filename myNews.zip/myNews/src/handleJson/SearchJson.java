package handleJson;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;
import net.sf.json.JSONException;
import net.sf.json.JSONObject;
@WebServlet("/SearchJson")
public class SearchJson extends HttpServlet{

	public SearchJson() {
		super();
        // TODO Auto-generated constructor stub
	}
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String id = req.getParameter("id");//����ajax�еĲ���id
		String callback = req.getParameter("callback");//����ajax�еĲ���callback
		req.setCharacterEncoding("utf-8");//���ñ���
		resp.setContentType("application/json;charset=utf-8");
		PrintWriter out = resp.getWriter();
		String uri="jdbc:mysql://127.0.0.1/mynews?"+
	            "user=root&password=123456&characterEncoding=utf-8&useSSL=false";
	    String sql = "select * from tb_news where tb_news.id="+id;
	    JSONObject jobj = new JSONObject();
	    JSONArray jArr = new JSONArray();
		
	    try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(uri);
			Statement st =  con.createStatement();
			ResultSet rs = st.executeQuery(sql);
			ResultSetMetaData rsmd = rs.getMetaData();
			int colnum = rsmd.getColumnCount();
			String val = "";
			String colName = "";
			
			while(rs.next()) {
	            for(int i = 1; i<=colnum; i++) {
	                colName = rsmd.getColumnLabel(i);
	                try {
	                    if(i==1) {
	                    	val = rs.getString(colName);
	                    	jobj.put(colName, Integer.parseInt(val));
	                    }else {
	                        val = rs.getString(colName);
	                        jobj.put(colName, val);
	                    }  
	                } catch (JSONException e) {
	                    // TODO Auto-generated catch block
	                    e.printStackTrace();
	                }            
	            }
	            jArr.add(jobj);    
	        } 	
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    out.print(callback+"("+jArr+")");
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		super.doPost(req, resp);
	}
	
}
